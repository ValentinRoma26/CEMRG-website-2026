function [dmso,the,tox] = uniProtMagSig(Entry, c,t)
%
% Calculate net enhancement/suppression factor for each reaction
% following drug exposure at therapeutic or toxic doses after t days.
%
% Inputs:
%   Entry = 1D cell array of Uniprot codes for affected proteins
%   c = polynomial-fit coefficients from proteomics.
%   t = time in days after start of drug treatment
%
% Outputs: 
%   Expected net enhancement/suppression factors at time t (hours) for each
%   reaction in the mitochondrion system following therapeutic or toxic
%   exposure. (dmso = control)
%

%%
dmso=ones(99,1);
the=ones(99,1);
tox=ones(99,1);
counter=zeros(30,1);

for i=1:length(Entry)
    index=-1;
    switch char(Entry(i)),
        % --------TCA Cycle-----------------------------------------------
        % 1-Citrate synthase
        case 'O75390'
            index=1;
            % 2-Aconitate hydratase
        case 'Q99798'
            index=2;
            % 3-Isocitrate dehydrogenase
        case {'O43837','P48735','P50213','P51553'}
            index=3;
            % 4-Oxoglutarate dehydrogenas
        case 'Q02218'
            index=4;
            % 5-Succinyl-CoA ligase
        case {'Q9P2R7','Q96I99','P53597'}
            index=5;
            % 6-Fumarate hydratase
        case 'P07954'
            index=6;
            % 7-Malate dehydrogenase
        case 'P40926'
            index=7;
            % -----Electron Transport Chain------------------------------------------
            % 8-Complex I - (mtDNA)
        case {'P49821','O75251','O00217','P19404','O75489','O75306','P28331','P03886','P03891','P03897','P03905','P03901','P03915','P03923'}%26
            index=8;
            % 9-Complex II - (mtDNA)
        case {'O14521','Q99643','P21912','P31040'}%30
            index=9;
            %10-Complex III
        case {'P00156','P08574','P47985','P31930','P22695','P07919','P14927','O14949','Q9UDW1','O14957'}
            index=10;
            %11-Complex IV - (mtDNA)
        case {'P00395','P00403','P00414','P13073','Q96KJ9','P20674','P10606','P12074','Q02221', 'P14854','Q6YFQ2','P09669','P24310','P14406','O60397','P24311','P15954','O14548','P10176','Q7Z4L0'}%60
            index=11;
            %12-ATP synthase (mtDNA)
        case {'Q5VTU8 ','P24539',' P05496',' Q06055 ','P48201',' P56381',' O75947 ','P18859 ','P00846',' P03928','P25705','P06576','P30049','P36542','P56134','P48047','Q8N5M1','Q5TC12','Q99766','O75964','Q7Z4Y8','P56385','Q9NW81'}%83
            index=12;
            %------------ Membrane Carriers---------------------------------------------
            %13-ADP/ATP translocase
        case {'P12235','P05141','P12236','Q9H0C2'}%87
            index=13;
            %14-Sodium/calcium exchanger
        case {'P32418','Q9UPR5','P57103'}%90
            index=14;
            %15-Sodium/hydrogen exchanger
        case {'P19634','P48764','Q6AI14','Q9UBY0','Q14940','Q96T83','Q9Y2E8','Q8IVB4','Q92581'}
            index=15;
            %16-Calcium uniporter
        case {'Q9H4I9','Q8NE86','Q9NWR8','Q96AQ8','Q9BPX6','Q8IYU8'}%105
            index=16;
            %17-Phosphate carrier
        case 'Q00325'
            index=17;
            %18- NAD(P) transhydrogenase, mitochondrial
        case 'Q13423'
            index=18;
            %19-Proton Leak
        case 'P55851'
            index=19;
            %----------ROS Scavengers---------
            %20-Superoxide dismutase [Mn]
        case 'P04179'
            index=20;
            %21-Glutathione peroxidase
        case 'P22352'
            index=21;
            %22-Cyto thioredoxin reductase (TrxR1)
        case 'Q16881'
            index=22;
            %23-Glutaredoxin
        case 'Q9NS18'
            index=23;
            %24- Mitho Peroxiredoxin
        case {'P30048','P30044'}
            index=24;
            %25-Superoxide dismutase [Cu-Zn]
        case 'P00441'
            index=25;
            %26-Mitho thioredoxin reductase (TrxR2)
        case 'Q9NNW7'
            index=26;
            %27-Cyto Peroxiredoxin
        case {'	P30041','Q06830','Q13162','P32119'}
            index=27;
            %28-Mitho Glutathione reductase
        case 'P00390'
            index=28;
            %29-Catalase
        case 'P04040'
            index=29;
            %----------Others---------
            %30-Aspartate aminotransferase, mitochondrial
        case 'P00505'
            index=30;
    end
    
    if((index>0))
        tmp=2^(c(i,1)+c(i,4)*t+c(i,7)*t*t)/2^c(i,1);
        dmso(index)=(dmso(index)*counter(index)+tmp)/(counter(index)+1);
        
        tmp=2^((c(i,1)+c(i,2))+(c(i,4)+c(i,5))*t+(c(i,7)+c(i,8))*t*t)/2^(c(i,1)+c(i,2));
        the(index)=(the(index)*counter(index)+tmp)/(counter(index)+1);
        
        tmp=2^((c(i,1)+c(i,3))+(c(i,4)+c(i,6))*t+(c(i,7)+c(i,9))*t*t)/2^(c(i,1)+c(i,3));
        tox(index)=(tox(index)*counter(index)+tmp)/(counter(index)+1);
        
        counter(index)=counter(index)+1;
    end
    
end
