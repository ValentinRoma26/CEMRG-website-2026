simParams = struct;
simParams.RT_over_F = 26.708186528497409326424870466321;  %T = 37degC
simParams.pH_n = 7.3;
simParams.pH_p = 7.0;

simParams.O2 = 8.5e-3;
simParams.O2dot = 1e-5;

simParams.ich=0.0;
simParams.aox=0.0;

simParams.DpsiClamp = -1;
simParams.NADH = 2.3055;
simParams.NAD = 7.685;
simParams.succON = 0.2;
simParams.myxothiazolBlock = 1;
simParams.antimycinBlock = 1;
simParams.rotenoneBlock = 1;
simParams.CNBlock = 1;
simParams.c3Block = 1;
simParams.gh = 2e-6;

simParams.DOXconc=0;
simParams.ATPMg = 0.01; 
simParams.ADP3 = 0.0110;


simParams.t_pacing = 3e5;
simParams.t_pacing = 0;
simParams.t_rest = 6e6;
simParams.t_pacing2 = 9e999;
simParams.BCL = 250;

simParams.ADP1 = 0.1;
simParams.ADP2 = 1;

simParams.pH_final = 7.4573;
simParams.conservePMF = 0;
simParams.Nai = 5;

simParams.uniBlock = 0;
simParams.mNCEBlock = 0;

simParams.AcCoA = .1;
simParams.GLU = 30;
simParams.Etxrm=3.5e-1*0.00035;
simParams.Etxr=3.5e-1*0.00035;
simParams.EtGR= 2.5e-1*9e-4;
simParams.EtGRm= 2.5e-1*9e-4;
% simParams.EtGR=1e-9;  %for scavenging inhibition
% simParams.EtGRm=1e-9;  %for scavenging inhibition
simParams.useAcCoAEXP= false;
simParams.useGluEXP = false;
simParams.useADPEXP = false;


simParams.ACOinhib = 1.0;

simParams.tmp =0.0;
simParams.RC =0.0;
simParams.tmp1 =1.0;
simParams.tmp2 =1.0;
simParams.tmp3 =1.0;
simParams.tmp4 =1.0;
simParams.tmp5 =1.0;
simParams.tmp6 =1.0;

simParams.DNAon = 0.0;

