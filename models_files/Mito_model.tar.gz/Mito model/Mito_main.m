% ========================================================================
%        MITOCHONDRIAL MODEL - Impact of anthracycline exposure
% ========================================================================
%
% PROGRAMME INPUTS:
%   The affect of each anthracyclines on the mitochondrion system is
%   contained in the data files DOX.mat, DAU.mat, EPI.mat, IDA.mat. Each
%   file contains: 
%        Gene = list of affected proteins (Uniprot codes) (414 genes)
%        coeff = array of polynomial coefficients obtained by fitting proteomics
%        data. (414 genes x 9 coefficients)
%
% PROGRAMME OUTPUTS:
%   Xss_dmso, Xss_the, Xss_tox: (15 time points x 38 state variables)
%       = steady-state solutions of the system for time = 0..14 days for
%       each drug exposure: dmso (control), therapeutic, toxic
%   J_dmso, J_the, J_tox (15 time points x 34 fluxes)
%       = fluxes through reactions (see Mito_reactions.pdf for 
%       labeled diagram of reactions). 
%


clear all
clc

WhichDrug = 'DOX';  % otherwise 'IDA'   'EPI'   'DAU'



%% Get baseline mito system

% Define initial conditions
IC = [1.70070739785949e-05,0.169099609120200,178.433173963957,0.961798726397941,3.48915863711387e-05,0.126123434851040,0.322241518246673,0.0553785576477727,0.0773212762127356,0.00468208323070382,0.102197335553295,0.0966402126192478,0.00143982881698293,0.0976260101594860,4.34177778966825e-05,1.71011471182717e-07,6.64037961850106e-06,2.37182963398066e-08,0.883118013672602,4040.95276088845,0.0584409931636982,0.0249210185827156,0.0499894772983332,0.000875597856748719,2.67695197932744e-05,1.92413794713778,0.0863261339212658,0.0207814988333664,0.0207656761850215,0.0238446844922628,1.92415376978613,0.232280305011119,0.0692214017748037,0.0227018759576134,0.208744348662550,0.284300768814984,0.250285385983941,1.0];

% Integrate ODE system to get baseline conditions
options = odeset('RelTol', 1e-6);
t_final=50*60e6; % Hours to reach steady state

par(1,:) = ones(1,99);

getSimParams;  % Define simParams data structure.
simParams.t_pacing = 1e20; 
simParams.t_rest = 1e20;
simParams.BCL = 333;
simParams.t_pacing = 5*60e3;
simParams.t_rest = 100*60e3;

[t, X] = ode15s(@Mito_ODE, 0:60e3:t_final, IC, options, par, simParams);
ICs_c = X(length(t),:);

clear t X


%% Calculate drug effect


load(['/home/al12/Dropbox/MATLAB/2018 09 30 Bernardo code/files/' WhichDrug '.mat'], ...
    'Gene', ... % list of affected genes (uniprot codes)
    'coeff') % polynomial fit coefficients describing drug effect
    

Xr_dmso=[];
Xr_the=[];
Xr_tox=[];
J_dmso=[];
J_the=[];
J_tox=[];

for day = 0:14  % time in days
    disp(['Doing day ' num2str(day)])
    
    % Get enhancement/suppression ratios
    [dmso,the,tox] = uniProtMagSig(Gene,coeff,day*24); 
    
    % Solve Mito_ODE  to steady state for each drug exposure
    
    % DMSO control:
    [t, X1] = ode15s(@Mito_ODE, 0:60e3:t_final, ICs_c, options, dmso, simParams);
    [~,J_dmso(end+1,:)]= Mito_ODE(t1(end),X1(end,:), dmso, simParams);
    Xr_dmso(end+1,:,:)=X1; clear X1
    
    % Therapeutic dose:
    [t, X1] = ode15s(@Mito_ODE, [0:60e3:t_final], ICs_c, options, the, simParams);
    [~,J_the(end+1,:)]= Mito_ODE(t1(end),X1(end,:), the, simParams);
    Xr_the(end+1,:,:)=X1; clear X1
    
    % Toxic dose:
    [t, X1] = ode15s(@Mito_ODE, [0:60e3:t_final], ICs_c, options, tox, simParams);
    [~,J_tox(end+1,:)]= Mito_ODE(t1(end),X1(end,:), tox, simParams);
    Xr_tox(end+1,:,:)=X1; clear X1
end

Xss_dmso = squeeze(Xr_dmso(:,end,:));
Xss_the = squeeze(Xr_the(:,end,:));
Xss_tox = squeeze(Xr_tox(:,end,:));
clear Xr_dmso Xr_the Xr_tox