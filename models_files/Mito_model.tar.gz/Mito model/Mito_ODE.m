function [dydt, J] = Mito_ODE(t,X, par, simParams)


% Override parameters
simParams.rotenoneBlock= par(8);
simParams.tmp2= par(9);
simParams.antimycinBlock=par(10);
simParams.CNBlock=par(11);

mtDNA= X(38);
aDNA=  9e-12 ;
bDNA=  2.4e-6;
cDNA=  0.95*6e-6;
dDNA = 0.05;

Dpsi = X(3);
NADH = X(4);
Hm = X(5);
ISO = X(7);
aKG = X(8);
SUC = X(10);
FUM = X(11);
OAA = X(13);
NADPHm = X(14);
GSHm = X(19);
GSSGm = X(21);

C3_tot = .325 * simParams.tmp3 * mtDNA;   %*par(10);
C4_tot = .325 * mtDNA* simParams.tmp6;    % *par(11); %nmol/mg pn ~ mM


Q_n = X(26);
Qdot_n = X(27);
QH2_n = X(28);
QH2_p = X(29);
Qdot_p = X(30);
Q_p = X(31);
b1 = X(32);  %ox-ox
b2 = X(33);  %bL_red-bH_ox
b3 = X(34);  %bL_ox-bH_red
b4 = C3_tot-b1-b2-b3;  %red-red
if b4 < 0
    display('Negative b-heme state');
    pause;
end
FeS_ox = X(35);
FeS_red = C3_tot-FeS_ox;
c1_ox = X(36);
c_ox = X(37);
c1_red = C3_tot - c1_ox;
c_red = C4_tot - c_ox;

simParams.O2dot=X(15);
simParams.O2=simParams.O2*par(39);

% pacing protocol
BCL = simParams.BCL;
CaiWidth = 200;
t_pacing = simParams.t_pacing;
t_rest = simParams.t_rest;
ADP1 = simParams.ADP1;
ADP2 = simParams.ADP2;
ADP_rest = ADP2-(ADP2-ADP1)*exp(-(t_rest-t_pacing)/(2*60e3));
pH0 = 7.4573;
pH_final = simParams.pH_final;
pH_rest = (pH_final-pH0)*(1-exp(-(t_rest-t_pacing)/5e4))+pH0;

if t<t_pacing,
    ADP_cyto = ADP1; % 0.25 Hz pacing
    pH_n = pH0;
    Cai = 0.1e-3;
    VROS = 4.5e-6;
    
elseif t<simParams.t_pacing2,
    ADP_cyto = ADP2-(ADP2-ADP1)*exp(-(t-t_pacing)/(2*60e3)); % 0.25Hz pacing
    
    pH_n = (pH_final-pH0)*(1-exp(-(t-t_pacing)/1e5))+pH0;  % for Ru360, pH_final = 7.746
    if simParams.conservePMF,
        pH_n = (pmf-Dpsi)/2.303/2.670818E1+7; 
    end
    
    VROS = 4.5e-6*1;
    
    if mod(t,1000) < CaiWidth
        Cai = 1e-3 - 0.9e-3*exp(-(t-t_pacing)/(2*60e3)); 
    else
        Cai = 0.1e-3;
    end
    
elseif t<t_rest,
    ADP_cyto = ADP2-(ADP2-ADP1)*exp(-(t-t_pacing)/(2*60e3)); %0.25Hz pacing
    pH_n = (pH_final-pH0)*(1-exp(-(t-t_pacing)/1e5))+pH0;  %for Ru360, pH_final = 7.746
    if simParams.conservePMF,
        pH_n = (pmf-Dpsi)/2.303/2.670818E1+7;
    end
    VROS = 4.5e-6*1;
    if mod(t,BCL) < CaiWidth
        Cai = 1e-3 - 0.9e-3*exp(-(t-t_pacing)/(2*60e3));
    else
        Cai = 0.1e-3;
    end
else
    ADP_cyto = ADP1+(ADP_rest-ADP1)*exp(-(t-t_rest)/(2*60e3));  
    pH_n = (pH_rest-pH0)*(exp(-(t-t_rest)/5e4))+pH0; 
    VROS = 4.5e-6;
    if simParams.conservePMF,
        pH_n = (pmf-Dpsi)/2.303/2.670818E1+7;
    end
    Cai = 0.1e-3;
end

ADP_cyto= 1*par(38);
VROS = 4.5e-6;
Cai = .54e-3* par(36);
pH_n = -log10(Hm)+3;
VmPiC=4.9;
Conc_NHE=0.00785;
NADPHc=7.5E-2;
NAD=1.0-NADH;
RhoF1= 6* mtDNA *par(12);
VmANT=3.15;
Pi_cyto=3*par(37);
EtCuZnSOD= 2.4e-004;
EtMnSOD=0.0003;

EtGR= 9e-4 ;

EtGRm= 2.316453381248470e-03;
% EtGR=1e-9;  %for scavenging inhibition
% EtGRm=1e-9;  %for scavenging inhibition
Etxrm=0.00035 ;
Etxr=0.00035 ;
% Etxrm=1e-9;  %for scavenging inhibition
% Etxr=1e-9;  %for scavenging inhibition
Etcat=1e-6 ;
EtGPX=5e-5;
EtGPXm= 9.770749312457280e-05 ;

AcCoA= 0.1 *par(32);
GLU= 30 *par(31);


VNai = simParams.Nai*par(35);
Vmuni= .05*0.002459;
Vmuni = Vmuni*(1-simParams.uniBlock); 
VmNaCa = .5*9.33e-5;
VmNaCa = VmNaCa*(1-simParams.mNCEBlock);
VNam=-2/3.0E-4*X(1)-X(2)-1.812E-3*Dpsi-Hm/1.0E-5+X(6)+1.01E1;
beta_matr=1e-5;  %Mitochondrial proton buffering capacity

%% ------------------------ TCA cycle params-------------------------------
scale = 2.026679707499180e+01;
scale2 = scale;
KCS=7.841e-6*scale;
kfACO=3.896e-6*scale;
kfidh=0.0264*scale;
kfKG=0.000883*scale;
KfSL=0.0014*scale2 ;
kfFH=0.000415*scale;
kfMDH=0.00621*scale;
kfAAT=0.00107*scale;


%% ---------------binding polynomial equations-----------------------------

Hi=1.0E-4 *par(34);  %same
KaidADP=6.2E-1; %same
KaidCa=5.0E-4; %same, IDH activation constant for Ca2+
KaPi=1.78E-7;
KaATP=3.31E-7;
KMgATP=6.46E-5;
KaADP=4.17E-7;
KMgADP= 5.62E-4;
KaSUC=6.3E-6;
KaH2O=1.0E-14;
KSLeq=3.115;
kh_1=1E-5;
kh_2=9E-4;
kh_1a=4E-5;
kh_2a=7E-5;
khm1=1.131E-5;
khm2=2.67E1;
khm3=6.68E-9;
khm4=5.62E-6;
kmoff=3.99E-2;
Mg=0.4*par(33);
KkgCa= 1.5E-4;
Cm=1.5;
Catp=1.01;
ATPm = Cm - X(2);

H_mito_1000= Hm/1000;
Mg_1000=Mg/1000;
ATP4 = ATPm / ( 1+ H_mito_1000/KaATP + Mg_1000/ KMgATP);
ATPMg= ATP4 * Mg_1000 / KMgATP;
HATP=  ATP4 * H_mito_1000 / KaATP ;
ADP3=  X(2) / ( 1+ H_mito_1000/KaADP + Mg_1000/ KMgADP);
%ADPMg= ADP3 * Mg_1000/KMgADP;
HADP=  ADP3 * H_mito_1000/KaADP ;
H2Pi = X(6)/(1+ KaPi/H_mito_1000);
%HPi= H2Pi*KaPi/(H_mito_1000);
ATP4_cyto= (Catp-ADP_cyto) / (1+ Hi/1000/KaATP + 1/1000/KMgATP);
ADP3_cyto= (ADP_cyto)/ (1+ Hi/1000/KaADP + 1/1000/KMgADP);
polyATP=1+ H_mito_1000/KaATP + Mg_1000/KMgATP;
polyADP=1+ H_mito_1000/KaADP + Mg_1000/KMgADP;
polyPi = 1+ H_mito_1000/KaPi;
polyH2O =1+ H_mito_1000/KaH2O;
SUC_poly=1+ H_mito_1000/KaSUC;

DpH=-log10(1.0E-4)+log10(Hm);
muH=-2.303*2.670818E1*DpH+Dpsi;
KeqF1=1.71E6;   %equilibrium constant for ATP synthesis
KATPase_app=KeqF1*H_mito_1000*polyATP*polyH2O/(polyADP*polyPi);
VAF1=KATPase_app/X(6)*(ATPMg/(ADP3+HADP));
VHuden=-RhoF1/(exp(1.5E2/2.670818E1)+1.346E-4*exp(1.5E2/2.670818E1)*VAF1+(7.739E-7+6.65E-15*VAF1)*exp(3/2.670818E1*muH));
VATPase=((1.656E-6+9.651E-17*exp(1.5E2/2.670818E1)-4.585E-17*exp(3/2.670818E1*muH))*VAF1-1.656E-8*exp(3/2.670818E1*muH))*VHuden;
Vhu=(3.0E2*1.656E-8+3.0E2*1.656E-8*VAF1-3*(1.656E-8+3.373E-10)*exp(3/2.670818E1*muH))*VHuden;

%if (ADP_cyto > 1e-4) && (ATPm > 1e-4)
VANT=VmANT*(1-(ATP4_cyto*ADP3)/(ADP3_cyto*ATP4))*exp(-Dpsi/2.670818E1)/((1+ATP4_cyto/(ADP3_cyto)*exp(-1.8721E-2*Dpsi))*(1+ADP3/(ATP4))) *par(13);
%else
%    VANT=0.0;
%end

V2FRTdsi=2*(Dpsi-9.1E1)/2.670818E1;
Vuniden=(((1+Cai/1.9E-2)^4)+1.1E2/((1+Cai/3.8E-4)^(2.8)))*(1-exp(-V2FRTdsi));
Vuni=(Vmuni/1.9E-2*Cai*V2FRTdsi*(1+Cai/1.9E-2)^3)/Vuniden * par(16);

VnaCa=VmNaCa*exp(2.5E-1*V2FRTdsi)*X(1)/(Cai*((1+9.4/VNai)^3)*(1+3.75E-4/X(1))) * par(14);
gh = 2e-6;
Vhleak=gh*muH * par(19);

VCS = (KCS*4.0E-1*AcCoA/(1.26E-2+AcCoA))*X(13)/(X(13)+6.4E-4) * par(1);
VACO =kfACO*(1.3-aKG-X(9)-X(10)-X(11)-X(12)-X(13)-ISO*1.45045)* par(2);
Va=1/((1+ADP3/KaidADP)*(1+X(1)/KaidCa));
Vi=(1+NADH/1.9E-1);
Vb=1.0+Hm/kh_1+kh_2/Hm;
VIDH=kfidh*1.09E-1/(Vb+9.23E-1/NAD*Vi+((1.52/ISO)^2)*Va*(1+9.23E-1/NAD*Vi)) * par(3);
VKGa=1/((1+1.2987E1)*(1+X(1)/KkgCa));
VKGDH=kfKG*5E-1/(1.0 + Hm/kh_1a+kh_2a/Hm+VKGa*(3.0E1/aKG)^1.2+VKGa*(3.87E1/NAD))* par(4);
KSLeq_app = KSLeq * SUC_poly * polyATP / ( polyADP * polyPi );
VSL=KfSL*(X(9)*X(6)*X(2)-X(10)*(ATP4+HATP)*2.0E-2/KSLeq_app)*par(5);
VFH=kfFH*(X(11)-X(12)/1)*par(6);
V26=(1/(1+khm3/Hm+khm3*khm4/(Hm^2)))^2;
V27=1/(1+Hm/khm1+(Hm^2)/(khm1*khm2))+kmoff;
VMDH=kfMDH*V26*V27*1.54E-1/(1+1.493/X(12)*(1+X(13)/3.1E-2)+2.244E-1/NAD+1.493/X(12)*(1+X(13)/3.1E-2)*2.244E-1/NAD)*par(7);
VAAT=1.5E-6*6.6*GLU*X(13)/(1.5E-6*6.6/kfAAT+aKG)*par(30);
VBeta1p=(1.6E-1*2.4E1*Hi)/(1.585E-4*2.4E1+2.4E1*Hi+1.585E-4*VNai);
VBeta1n=(9.39E-2*2.4E1*Hm)/(1.585E-4*2.4E1+2.4E1*Hm+1.585E-4*VNam);
VBeta2p=(2.52E-2*1.585E-4*VNam)/(1.585E-4*2.4E1+2.4E1*Hm+1.585E-4*VNam);
VBeta2n=(4.29E-2*1.585E-4*VNai)/(1.585E-4*2.4E1+2.4E1*Hi+1.585E-4*VNai);
VpHm=-log10(Hm)+3;
VNaH=Conc_NHE*(((VBeta1p*VBeta2p)-(VBeta1n*VBeta2n))/(VBeta1p+VBeta1n+VBeta2p+VBeta2n))/(1+10^(3*(VpHm-8.52)))* par(15);
VPiC=VmPiC/60000*(9.0E1*Pi_cyto*1.0E-8/Hm/(1.106E1*4.084E-5)-9.0E1*H2Pi*1.0E-4/(1.106E1*4.084E-5))/(1+Pi_cyto/1.106E1+...
    1.0E-8/Hm/4.084E-5+Pi_cyto*1.0E-8/Hm/(1.106E1*4.084E-5)+H2Pi/1.106E1+1.0E-4/4.084E-5+H2Pi*1.0E-4/(1.106E1*4.084E-5)) * par(17);


%% --------------NADPH handling equations----------------------------------

kfIDH_NADP = 8.72e-2; 
krIDH_NADP = 5.45e-3 ; 
Km_IDH2_H = 0.5;
Km_IDH2_ISO = 0.045; %from Popova et al. 
Km_IDH2_NADP = 0.046; %from Popova et al.
Ki_IDH2_NADP = 2e-6;
Km_IDH2_NADPH = 1.2e-2;
Ki_IDH2_aKG = 0.080; %from Popova et al.

% IDH2 equations
VNADPm=1.0E-1-NADPHm;
VdenID_NADP=(1+Hm/Km_IDH2_H)*...
    (1 + ISO/Km_IDH2_ISO+VNADPm/Km_IDH2_NADP*(1+Ki_IDH2_NADP/VNADPm) + aKG/Ki_IDH2_aKG+NADPHm/Km_IDH2_NADPH...
    +ISO/Km_IDH2_ISO*VNADPm/Km_IDH2_NADP*(1+Ki_IDH2_NADP/VNADPm) + aKG/Ki_IDH2_aKG*NADPHm/Km_IDH2_NADPH + ISO/Km_IDH2_ISO*NADPHm/Km_IDH2_NADPH+...
    aKG/Ki_IDH2_aKG*VNADPm/Km_IDH2_NADP*(1+Ki_IDH2_NADP/VNADPm));
VIDH_NADP=(kfIDH_NADP*ISO/Km_IDH2_ISO*VNADPm/Km_IDH2_NADP*(1+Ki_IDH2_NADP/VNADPm)-krIDH_NADP*aKG/Ki_IDH2_aKG*NADPHm/Km_IDH2_NADPH)/VdenID_NADP;

Et_THD = 1e-3; 
Kf_THD = 1.17474 ;
Kr_THD =  17.2756;
% From Humphrey et al. Biochem J 1957 -- TPN+ == NADP+, DPN+ == NAD+
KmNADP = 2e-2;
KmNAD = 1.25e-1;
KmNADPH = .4e-2;
KmNADH = 1e-2;
d = 0.5;
x = 0.1;
VDNADP=exp(muH*x*d/simParams.RT_over_F);
VDNAD=exp(muH*x/simParams.RT_over_F*(d-1));
VTHDen=1+NADH/KmNADH+NAD/KmNAD+VNADPm/KmNADP+NADPHm/KmNADPH+NADH/KmNADH*VNADPm/KmNADP*VDNADP+NADPHm/KmNADPH*NADH/KmNADH*VDNAD+...
    +NAD/KmNAD*VNADPm/KmNADP*VDNADP*VDNAD+NADH/KmNADH*NADPHm/KmNADPH;
VTHD=Et_THD*(Kf_THD*NADH/KmNADH*VNADPm/KmNADP*VDNADP-Kr_THD*NAD/KmNAD*NADPHm/KmNADPH*VDNAD)/VTHDen * par(18);


%% ----------------- scavenging equations----------------------------------
VIMAC=(1.0E-3+1.0E4/(1+1.0E-2/X(16)))*(3.5E-8+3.9085E-6/(1+exp(7.0E-2*(4.0+Dpsi))))*Dpsi * par(40);
VtrROS=-1.0E-1*(-Dpsi-2.6730818E1*log(X(15)/X(16)))/Dpsi*VIMAC;
VMnSOD=2*1.2E3*2.5E-4*(1.2E3+2.4E1*(1+X(17)/5.0E-1))*EtMnSOD*X(15)/(2.5E-4*(2*1.2E3+2.4E1*(1+X(17)/5.0E-1))+1.2E3*2.4E1*(1+X(17)/5.0E-1)*X(15)) * par(20);
VCuZnSOD=2*1.2E3*2.5E-4*(1.2E3+2.4E1*(1+X(18)/5.0E-1))*EtCuZnSOD*X(16)/(2.5E-4*(2*1.2E3+2.4E1*(1+X(18)/5.0E-1))+1.2E3*2.4E1*(1+X(18)/5.0E-1)*X(16)) *par(25);

Phi1 = 5.0e-5;
Phi2 = 27;
VGPXm=EtGPXm*X(17)*GSHm/(Phi1*GSHm+Phi2*X(17)) *par(21);

kGR=2.5E-3;
Km_GRm_NADPH = 6.53890269453546e-2;
Km_GRm_GSSG = 20.6e-3; % lowest Carlberg and Mannervik data point is 20.6e-3, highest is 108uM = .108mM
VGRm=kGR*EtGRm./(1+Km_GRm_GSSG./GSSGm+Km_GRm_NADPH./NADPHm+Km_GRm_GSSG./GSSGm.*Km_GRm_NADPH./NADPHm)*par(28);

VGPX=EtGPX*X(18)*X(20)/(Phi1*X(20)+Phi2*X(18))* par(21);
GSHi_tot = 2; % under the approximation that GSH transport is off
VGSS = 0.5*(GSHi_tot-X(20)); %!!!
Km_GRi_NADPH = 1.5e-2;
VGR=kGR*EtGR/(1+6.0E-2/VGSS+Km_GRi_NADPH/NADPHc+6.0E-2/VGSS*Km_GRi_NADPH/NADPHc)*par(28);

TrxTm=0.025;        %total amount of TrsSH2m
TrxT= 0.05 ;        %total amount of TrsSH2i
TrxSSm=TrxTm-X(22);
TrxSS=TrxT-X(23);

%thioredoxin peroxidases
EoTxPXm = 0.003 ;
EoTxPX=0.1;
Phi2Trx= 1.85;      %from Sztajer et al., JBC 2001 vol 276 7397-7403 % in VTxPxm and VTxPx
Phi1Trx= 3.83;
VTxPXm = EoTxPXm*X(17)*X(22)/(Phi2Trx*X(22)+Phi1Trx*X(17))*par(24);
VTxPX = EoTxPX*X(18)*X(23)/(Phi2Trx*X(23)+Phi1Trx*X(18))*par(27);

%thioredoxin reductases
kcXR= 22.75E-3;
KMTrxSS= 0.035;
KMnadph= 0.065;
VTxRm = Etxrm*kcXR/(1+KMTrxSS/TrxSSm+KMnadph/NADPHm+KMTrxSS/TrxSSm*KMnadph/NADPHm)*par(26);
VTxR = Etxr*kcXR/(1+KMTrxSS/TrxSS+KMnadph./NADPHc+KMTrxSS/TrxSS*KMnadph./NADPHc)*par(22);

Vem= 2.06E-5;   % extramatrix volume
Vm= 5.17E-6;    % matrix volume
c_difH2O2=2.0E-4 ;
VdifH2O2=c_difH2O2*(X(17)-X(18));

kcat=1.7E1;
Vcat=2*kcat*Etcat*X(18)*exp(-5.0E-2*X(18))*par(29);

c_VGST=1.5E-8;
VGST=c_VGST*(X(20)-X(19))/(X(20)+2.6);
VGST=c_VGST*(X(20)-X(19))/2.6;
VGST = 0;

% protein glutathionylation
kgrxm=3.6E-4;        %in (ms-1) en VGRXm
kgrx=3.6E-4 ;        %in (ms-1) en VGRX
KeqGRX=1.37E-3;      %en en VGRXm y en VGRX
GrxT= 0.002;         %en en VGRXm y en VGRX
KmGrx=0.01 ;         %estimated %en en VGRXm y en VGRX
KmPSSG= 0.0005;      %estimated  %en en VGRXm y en VGRX
VGRXm=kgrxm*KeqGRX*X(19)^2*GrxT*X(24)/((GSSGm+KeqGRX*X(19)^2)*(KeqGRX*X(19)^2*GrxT/(GSSGm+KeqGRX*X(19)^2)+KmGrx)*(X(24)+KmPSSG));
VGRX=kgrx*KeqGRX*X(20)^2*GrxT*X(25)/((VGSS+KeqGRX*X(20)^2)*(KeqGRX*X(20)^2*GrxT/(VGSS+KeqGRX*X(20)^2)+KmGrx)*(X(25)+KmPSSG));

VGRXm=VGRXm*par(23);
VGRX=VGRX*par(23);

PSSGT= 0.001;          %PSSG total; estimated  %en en VGRXm y en VGRX
kcatPSH= 0.64;         %kcat de enzima de PSH + GSH
EtPSH=0.8e-3;          %concentracion de enz
kmGSH=0.75;            %km de GSH
kactH2O2=1e-3;         %k activation of H2O2
VPSSGm=kcatPSH*EtPSH*(PSSGT-X(24))/(1+(kmGSH/X(19))/(1+(X(17)/kactH2O2)));
VPSSGi=kcatPSH*EtPSH*(PSSGT-X(25))/(1+(kmGSH/X(20))/(1+(X(18)/kactH2O2)));
VPSSGm = 0; %!!!
VPSSGi = 0;


%% ------------- ETC MODEL     complex I-----------------------------------

parameterTrial_c1 = [0.114147820723305,1.59784103254246,9.99991429659771,61.5385020075147,114.118151557370,...
    0.0206803977208407,16.3056727383927,2.91670197986420,0.326041267378776,22.1225360173174;];

fwd1 = parameterTrial_c1(1);  %a23
fwd2 = parameterTrial_c1(2);  %a34
fwd3 = parameterTrial_c1(3);  %a47
fwd4 = parameterTrial_c1(4);  %a75
rev1 = parameterTrial_c1(5);  %a32
rev2 = parameterTrial_c1(6);  %a43
rev3 = parameterTrial_c1(7);  %a74
rev4 = parameterTrial_c1(8);
ROSscale = parameterTrial_c1(9) *1.7;
rhoRENscale = parameterTrial_c1(10);
fwd5 = 1;
rev5 = 1;
rev6 = 1;

RT_over_F = 26.708186528497409326424870466321;
F_over_RT = 1/RT_over_F;
pH_p = 7.0;
Hi = 10^(-pH_p+3); %mM
rhoREN = 25 * simParams.tmp5 *mtDNA;
DpsiB = 50;
g = 1.202658601212640e+00;

a12_ =  6.3396e+011;
a12 = a12_*(10^-(pH_n-3))^2;
a21 = 5;

a56 = 100;
a65_ =  2.5119e+013; %per mM^2
a65 = rev6*a65_*Hi^2;

a61_ = 1e7;
a61 = fwd5*a61_*exp(-2*.5*g*(Dpsi-DpsiB)*F_over_RT);
a16_ = 130;
a16 = rev5*a16_*exp(2*.5*g*(Dpsi-DpsiB)*F_over_RT);
a25 = 0;
a52 = 0;

%--------------------------------------------------------------------

a23_ = fwd1*3.405e4; %/sqrt(nmol/mg)/s  
a23 = a23_*sqrt(NADH);
a32 = rev1*8e4;

a34 = fwd2*400;
a43_ = rev2*159;
a43 = a43_*sqrt(NAD); % = 441 for NAD = 7.685nmol/mg-pn;


a47_ =  fwd3*7.9810e+003/.005;
a47 = a47_*sqrt(Q_n)*10^-(pH_n-3) ;
a74 = 10*rev3*0.4;  %scale factor is for reversibility

a75 = 10*fwd4*40;
a57_ = 10*100*.4;
a57 = rev4*a57_*sqrt(QH2_n);

a47 = a47*simParams.rotenoneBlock*simParams.tmp1;;
a57 = a57*simParams.rotenoneBlock;

E_FMN = -0.375; % V at pH 7.5
E_O2dot = -0.15;
KeqROS = exp(2*(E_O2dot-E_FMN)/RT_over_F);  
a42 = (simParams.tmp*exp(-8e-9.*t).* (1-exp(-2.3e-6.*t))+1)*ROSscale*18.5*simParams.O2;  
a24 = a42*KeqROS*simParams.O2dot;


%  numerator
E(1) =  a21*a61*a32*a42*a52*a74+a21*a61*a32*a42*a52*a75+a21*a61*a32*a42*a56*a74+a21*a61*a32*a42*a74*a57+a21*a61*a32*a42*a56*a75+a21*a61*a32*a52*a43*a74+a21*a61*a32*a52*a43*a75+a21*a61*a32*a52*a75*a47+a21*a61*a32*a56*a43*a74+a21*a61*a32*a43*a74*a57+a21*a61*a32*a56*a43*a75+a21*a61*a32*a56*a75*a47+a21*a61*a42*a52*a34*a74+a21*a61*a42*a52*a34*a75+a21*a61*a42*a56*a34*a74+a21*a61*a42*a34*a74*a57+a21*a61*a42*a56*a34*a75+a21*a61*a52*a75*a47*a34+a21*a61*a56*a75*a47*a34+a21*a32*a42*a52*a74*a65+a21*a32*a42*a52*a65*a75+a21*a32*a42*a74*a57*a65+a21*a32*a52*a43*a65*a74+a21*a32*a52*a43*a65*a75+a21*a32*a52*a65*a75*a47+a21*a32*a43*a74*a57*a65+a21*a42*a52*a34*a74*a65+a21*a42*a52*a34*a65*a75+a21*a42*a34*a74*a57*a65+a21*a52*a65*a75*a47*a34+a61*a56*a25*a32*a42*a74+a61*a56*a25*a75*a32*a42+a61*a56*a75*a47*a24*a32+a61*a56*a25*a32*a43*a74+a61*a56*a25*a75*a32*a43+a61*a56*a25*a75*a32*a47+a61*a56*a75*a47*a34*a23+a61*a56*a25*a42*a34*a74+a61*a56*a25*a75*a42*a34+a61*a56*a75*a47*a24*a34+a61*a56*a25*a75*a47*a34;
E(2) =  a12*a32*a42*a52*a61*a74+a12*a32*a42*a52*a61*a75+a12*a32*a42*a61*a74*a56+a12*a32*a42*a61*a74*a57+a12*a32*a42*a61*a56*a75+a12*a32*a52*a61*a43*a74+a12*a32*a52*a61*a43*a75+a12*a32*a52*a61*a75*a47+a12*a32*a61*a43*a56*a74+a12*a32*a61*a43*a74*a57+a12*a32*a61*a43*a56*a75+a12*a32*a61*a56*a75*a47+a12*a42*a52*a61*a34*a74+a12*a42*a52*a61*a34*a75+a12*a42*a61*a34*a74*a56+a12*a42*a61*a34*a74*a57+a12*a42*a61*a34*a56*a75+a12*a52*a61*a75*a47*a34+a12*a61*a56*a75*a47*a34+a12*a32*a42*a52*a74*a65+a12*a32*a42*a52*a65*a75+a12*a32*a42*a74*a57*a65+a12*a32*a52*a43*a65*a74+a12*a32*a52*a43*a65*a75+a12*a32*a52*a65*a75*a47+a12*a32*a43*a74*a57*a65+a12*a42*a52*a34*a74*a65+a12*a42*a52*a34*a65*a75+a12*a42*a34*a74*a57*a65+a12*a52*a65*a75*a47*a34+a32*a42*a52*a74*a65*a16+a32*a42*a52*a65*a75*a16+a32*a42*a74*a57*a65*a16+a32*a52*a43*a65*a74*a16+a32*a52*a43*a65*a75*a16+a32*a52*a65*a75*a16*a47+a32*a43*a74*a57*a65*a16+a42*a52*a34*a74*a65*a16+a42*a52*a34*a65*a75*a16+a42*a34*a74*a57*a65*a16+a52*a65*a75*a16*a47*a34;
E(3) =  a23*a12*a42*a52*a61*a74+a23*a12*a42*a52*a61*a75+a23*a12*a42*a61*a74*a56+a23*a12*a42*a61*a74*a57+a23*a12*a42*a61*a56*a75+a23*a43*a12*a52*a74*a61+a23*a43*a12*a52*a61*a75+a23*a12*a52*a61*a75*a47+a23*a43*a12*a74*a61*a56+a23*a43*a12*a74*a61*a57+a23*a43*a12*a61*a56*a75+a23*a12*a61*a56*a75*a47+a43*a24*a74*a12*a52*a61+a43*a24*a12*a52*a61*a75+a43*a24*a74*a12*a61*a56+a43*a24*a74*a12*a57*a61+a43*a24*a12*a61*a56*a75+a43*a74*a57*a25*a12*a61+a43*a74*a57*a65*a16*a21+a23*a12*a42*a52*a74*a65+a23*a12*a42*a52*a65*a75+a23*a12*a42*a74*a57*a65+a23*a43*a12*a52*a74*a65+a23*a43*a12*a52*a65*a75+a23*a12*a52*a65*a75*a47+a23*a43*a12*a74*a57*a65+a43*a24*a74*a12*a52*a65+a43*a24*a12*a52*a65*a75+a43*a24*a74*a12*a57*a65+a43*a74*a57*a25*a65*a12+a23*a42*a52*a74*a65*a16+a23*a42*a52*a65*a75*a16+a23*a42*a74*a57*a65*a16+a23*a43*a52*a74*a65*a16+a23*a43*a52*a65*a75*a16+a23*a52*a65*a75*a16*a47+a23*a43*a74*a57*a65*a16+a43*a24*a74*a52*a65*a16+a43*a24*a52*a65*a75*a16+a43*a24*a74*a57*a65*a16+a43*a74*a57*a25*a65*a16;
E(4) =  a24*a74*a12*a32*a52*a61+a24*a12*a32*a52*a61*a75+a24*a74*a12*a32*a61*a56+a24*a74*a12*a32*a57*a61+a24*a12*a32*a61*a56*a75+a34*a74*a23*a12*a52*a61+a34*a23*a12*a52*a61*a75+a74*a57*a25*a12*a32*a61+a34*a74*a23*a12*a61*a56+a34*a74*a23*a57*a12*a61+a34*a23*a12*a61*a56*a75+a74*a57*a65*a16*a21*a32+a24*a34*a74*a12*a52*a61+a24*a34*a12*a52*a61*a75+a24*a34*a74*a12*a61*a56+a24*a34*a74*a12*a57*a61+a24*a34*a12*a61*a56*a75+a34*a74*a57*a25*a12*a61+a34*a74*a57*a65*a16*a21+a24*a74*a12*a32*a52*a65+a24*a12*a32*a52*a65*a75+a24*a74*a12*a32*a57*a65+a34*a74*a23*a12*a52*a65+a34*a23*a12*a52*a65*a75+a74*a57*a25*a65*a12*a32+a34*a74*a23*a57*a12*a65+a24*a34*a74*a12*a52*a65+a24*a34*a12*a52*a65*a75+a24*a34*a74*a12*a57*a65+a34*a74*a57*a25*a65*a12+a24*a74*a32*a52*a65*a16+a24*a32*a52*a65*a75*a16+a24*a74*a32*a57*a65*a16+a34*a74*a23*a52*a65*a16+a34*a23*a52*a65*a75*a16+a74*a57*a25*a65*a32*a16+a34*a74*a23*a57*a65*a16+a24*a34*a74*a52*a65*a16+a24*a34*a52*a65*a75*a16+a24*a34*a74*a57*a65*a16+a34*a74*a57*a25*a65*a16;
E(5) =  a25*a12*a32*a42*a61*a74+a25*a75*a12*a32*a42*a61+a65*a16*a21*a32*a42*a74+a75*a47*a24*a12*a32*a61+a65*a75*a16*a21*a32*a42+a25*a12*a32*a61*a43*a74+a25*a75*a12*a32*a61*a43+a25*a75*a12*a32*a47*a61+a65*a16*a21*a32*a43*a74+a75*a47*a34*a23*a12*a61+a65*a75*a16*a21*a32*a43+a65*a75*a16*a47*a21*a32+a25*a12*a42*a61*a34*a74+a25*a75*a12*a42*a61*a34+a65*a16*a21*a42*a34*a74+a75*a47*a24*a34*a12*a61+a65*a75*a16*a21*a42*a34+a25*a75*a12*a47*a61*a34+a65*a75*a16*a47*a21*a34+a25*a65*a12*a32*a42*a74+a25*a65*a75*a12*a32*a42+a65*a75*a47*a24*a12*a32+a25*a65*a12*a32*a43*a74+a25*a65*a75*a12*a32*a43+a25*a65*a75*a12*a32*a47+a65*a75*a47*a34*a23*a12+a25*a65*a12*a42*a34*a74+a25*a65*a75*a12*a42*a34+a65*a75*a47*a24*a34*a12+a25*a65*a75*a12*a47*a34+a25*a65*a32*a42*a16*a74+a25*a65*a75*a32*a42*a16+a65*a75*a16*a47*a24*a32+a25*a65*a32*a16*a43*a74+a25*a65*a75*a32*a16*a43+a25*a65*a75*a32*a16*a47+a65*a75*a16*a47*a34*a23+a25*a65*a42*a16*a34*a74+a25*a65*a75*a42*a16*a34+a65*a75*a16*a47*a24*a34+a25*a65*a75*a16*a47*a34;
E(6) =  a16*a21*a32*a42*a52*a74+a16*a21*a32*a42*a52*a75+a16*a56*a21*a32*a42*a74+a16*a21*a32*a42*a74*a57+a16*a56*a21*a75*a32*a42+a16*a21*a32*a52*a43*a74+a16*a21*a32*a52*a43*a75+a16*a21*a32*a52*a75*a47+a16*a56*a21*a32*a43*a74+a16*a21*a32*a43*a74*a57+a16*a56*a21*a75*a32*a43+a16*a56*a21*a75*a32*a47+a16*a21*a42*a52*a34*a74+a16*a21*a42*a52*a34*a75+a16*a56*a21*a42*a34*a74+a16*a21*a42*a34*a74*a57+a16*a56*a21*a75*a42*a34+a16*a21*a52*a75*a47*a34+a16*a56*a21*a75*a47*a34+a56*a25*a12*a32*a42*a74+a56*a25*a75*a12*a32*a42+a56*a75*a47*a24*a12*a32+a56*a25*a12*a32*a43*a74+a56*a25*a75*a12*a32*a43+a56*a25*a75*a12*a32*a47+a56*a75*a47*a34*a23*a12+a56*a25*a12*a42*a34*a74+a56*a25*a75*a12*a42*a34+a56*a75*a47*a24*a34*a12+a56*a25*a75*a12*a47*a34+a16*a56*a25*a32*a42*a74+a16*a56*a25*a75*a32*a42+a16*a56*a75*a47*a24*a32+a16*a56*a25*a32*a43*a74+a16*a56*a25*a75*a32*a43+a16*a56*a25*a75*a32*a47+a16*a56*a75*a47*a34*a23+a16*a56*a25*a42*a34*a74+a16*a56*a25*a75*a42*a34+a16*a56*a75*a47*a24*a34+a16*a56*a25*a75*a47*a34;
E(7) =  a47*a24*a12*a32*a52*a61+a57*a25*a12*a32*a42*a61+a47*a24*a12*a32*a61*a56+a47*a57*a24*a12*a32*a61+a57*a65*a16*a21*a32*a42+a47*a34*a23*a12*a52*a61+a57*a25*a12*a32*a61*a43+a47*a57*a25*a12*a32*a61+a47*a34*a23*a12*a61*a56+a47*a57*a34*a23*a12*a61+a57*a65*a16*a21*a32*a43+a47*a57*a65*a16*a21*a32+a47*a24*a34*a12*a52*a61+a57*a25*a12*a42*a61*a34+a47*a24*a34*a12*a61*a56+a47*a57*a24*a34*a12*a61+a57*a65*a16*a21*a42*a34+a47*a57*a34*a25*a12*a61+a47*a57*a34*a65*a16*a21+a47*a24*a12*a32*a52*a65+a57*a25*a65*a12*a32*a42+a47*a57*a24*a65*a12*a32+a47*a34*a23*a12*a52*a65+a57*a25*a65*a12*a32*a43+a47*a57*a25*a65*a12*a32+a47*a57*a34*a65*a23*a12+a47*a24*a34*a12*a52*a65+a57*a25*a65*a12*a42*a34+a47*a57*a24*a34*a65*a12+a47*a57*a34*a25*a65*a12+a47*a24*a32*a52*a65*a16+a57*a25*a65*a32*a42*a16+a47*a57*a24*a65*a32*a16+a47*a34*a23*a52*a65*a16+a57*a25*a65*a32*a16*a43+a47*a57*a25*a65*a32*a16+a47*a57*a34*a65*a23*a16+a47*a24*a34*a52*a65*a16+a57*a25*a65*a42*a16*a34+a47*a57*a24*a34*a65*a16+a47*a57*a34*a25*a65*a16;
% denominator
D = E(1) + E(2) + E(3) + E(4) + E(5) + E(6) + E(7);
% fractions
F(1) = E(1)/D;
F(2) = E(2)/D;
F(3) = E(3)/D;
F(4) = E(4)/D;
F(5) = E(5)/D;
F(6) = E(6)/D;
F(7) = E(7)/D;
Fc1=F;

%Jres is electron flux
%It takes two electrons to reduce 1/2 O2 to H2O
%VNO (nmol O/min/mg protein) is approximated by Jres/2
%VO2 ~ Jres/4
%reduction of Q to QH2 also takes two electrons
%dQH/dt = Jres/2 = VNO


%units are in mM/ms to go with scavenging model
Jres = 1e-3*rhoREN*(F(4)*a47-F(7)*a74)*simParams.tmp1;  %measure electron transport outside ROS loop
VROS_c1 =1e-3*rhoREN*(F(4)*a42-F(2)*a24)*simParams.tmp1;
%nmol O/min/mg protein

VNO_c1 = Jres/2;


parameterTrial_succ = [99998.1358697277,3640.22935731996,10000,800,100,5000,500,49949.0133694785,250,0.500609565121312,6.30957344480193e-05,1,0.125892541179417,0.501187233627272;];

k03 = parameterTrial_succ(1);
k04 = parameterTrial_succ(2);
k06 = parameterTrial_succ(3);
k07_bLox = parameterTrial_succ(4);
k07_bLred = parameterTrial_succ(5);
k08_bLox = parameterTrial_succ(6);
k08_bLred = parameterTrial_succ(7);
k09 = parameterTrial_succ(8);
V_succ = parameterTrial_succ(9);
beta = parameterTrial_succ(10);
scale = parameterTrial_succ(11:14);

RT_over_F = 26.708186528497409326424870466321;

%% ------------- ETC MODEL     complex II----------------------------------

Km_succ = 0.6;
alpha = (1-beta)/2;
gamma = alpha;
%deltas are symmetry factors in that they describe the
delta1 = 0.5;
delta2 = 0.5;
delta3 = 0.5;

%% ------------- ETC MODEL     complex III---------------------------------

%top most k0's are draft fit from February 13 or so
%next is optimized fit
%third is original Demin 1998 params


Keq_3 = exp(-1/RT_over_F*10);
k3 = k03*Keq_3*exp(2.3*(7-pH_p)); 
kminus3 = k03;

Keq_4_bHox = exp(1/RT_over_F*130);
k4_bHox = k04*Keq_4_bHox*exp(-alpha*delta1/RT_over_F*Dpsi);
kminus4_bHox = k04*exp(alpha*(1-delta1)/RT_over_F*Dpsi);

%Qpdot transfer to bL, bH reduced
Keq_4_bHred = exp(1/RT_over_F*70);
k4_bHred = k04*Keq_4_bHred*exp(-alpha*delta1/RT_over_F*Dpsi);
kminus4_bHred = k04*exp(alpha*(1-delta1)/RT_over_F*Dpsi);

kd = 1.32e6; %/min

Keq_6 = exp(1/RT_over_F*60);  
k6=k06*Keq_6*exp(-beta*delta2/RT_over_F*Dpsi);
kminus6 = k06*exp(beta*(1-delta2)/RT_over_F*Dpsi);

Keq_7_bLox = exp(1/RT_over_F*30);
k7_bLox = k07_bLox*Keq_7_bLox*exp(-gamma*delta3/RT_over_F*Dpsi);
kminus7_bLox = k07_bLox*exp(gamma*(1-delta3)/RT_over_F*Dpsi);

Keq_7_bLred = exp(1/RT_over_F*90);
k7_bLred = k07_bLred*Keq_7_bLred*exp(-gamma*delta3/RT_over_F*Dpsi);
kminus7_bLred = k07_bLred*exp(gamma*(1-delta3)/RT_over_F*Dpsi);

Keq_8_bLox = exp(1/RT_over_F*130);
k8_bLox = k08_bLox*Keq_8_bLox*exp(2.3*2*(7-pH_n))*exp(-gamma*delta3/RT_over_F*Dpsi);
kminus8_bLox = k08_bLox*exp(gamma*(1-delta3)/RT_over_F*Dpsi);

Keq_8_bLred = exp(1/RT_over_F*60);
k8_bLred = k08_bLred*Keq_8_bLred*exp(2.3*2*(7-pH_n))*exp(-gamma*delta3/RT_over_F*Dpsi);
kminus8_bLred = k08_bLred*exp(gamma*(1-delta3)/RT_over_F*Dpsi);

Keq_9 = exp(-1/RT_over_F*35);
k9 = k09*Keq_9;
kminus9 = k09;

k010 = 12*500*0.1; 
k010 = 34*500*0.1; 
Keq_10 = exp(1/RT_over_F*10);
k10 = k010*Keq_10;
kminus10 = k010;

E33_1 = 240; %c1_ox|c1_red
E33_2 = 260; %c_ox|c_red
k33 = 148148;
Keq33 = exp(max(E33_1-E33_2, E33_2-E33_1)/RT_over_F);
kminus33 = k33/Keq33;

%Q_n links complex I to dynamic Q pool
vc1 = VNO_c1;
Ki_OAA = 0.15; %mM
OAA_block = 1/(1+OAA/Ki_OAA);
succON = 0.085*sqrt(SUC/FUM);  
vc2 = simParams.tmp2*OAA_block*1e-3/60*succON*V_succ * Q_n/(Q_n+QH2_n) / (Km_succ + Q_n/(Q_n+QH2_n));
v1 = vc1 + vc2;

v2 = kd*(QH2_n-QH2_p);
v2 = v2/60e3;

v3 = k3*QH2_p*FeS_ox - kminus3*Qdot_p*FeS_red;
v3 = v3/60e3;

%transfer of electron from Qdotp to bL_ox
v4_bHox = k4_bHox*Qdot_p*b1 - kminus4_bHox*Q_p*b2;
v4_bHred = k4_bHred*Qdot_p*b3 - kminus4_bHred*Q_p*b4;
v4_bHox = 1e-3/60*v4_bHox*simParams.myxothiazolBlock;
v4_bHred = 1e-3/60*v4_bHred*simParams.myxothiazolBlock;

v5 = 1e-3/60*kd*(Q_p-Q_n);

v6 = k6*b2 - kminus6*b3;
v6 = 1e-3/60*v6;

v7_bLox = k7_bLox*Q_n*b3 - kminus7_bLox*Qdot_n*b1;
v7_bLred = k7_bLred*Q_n*b4 - kminus7_bLred*Qdot_n*b2;
v7_bLox = 1e-3/60*v7_bLox*simParams.antimycinBlock;
v7_bLred = 1e-3/60*v7_bLred*simParams.antimycinBlock;

v8_bLox = k8_bLox*Qdot_n*b3 - kminus8_bLox*QH2_n*b1;
v8_bLred = k8_bLred*Qdot_n*b4 - kminus8_bLred*QH2_n*b2;
v8_bLox = 1e-3/60*v8_bLox*simParams.antimycinBlock;
v8_bLred = 1e-3/60*v8_bLred*simParams.antimycinBlock;

v9 = k9*FeS_red*c1_ox - kminus9*FeS_ox*c1_red;
v9 = 1e-3/60*v9;

v10 = k10*Qdot_p*simParams.O2 - kminus10*Q_p*X(15);
v10 = 1e-3/60*v10;
VROS_SS = 0;

%reaction 33 -- cytochrome cl reduces cytochome c
v33 = k33*c1_red*c_ox - kminus33*c1_ox*c_red;
v33 = 1e-3/60*v33 ;

%% ------------- ETC MODEL     complex IV----------------------------------

%rates are in mM/min or 1/min
k34 = scale(1)*1000000*2.8e26;
k_34 = scale(1)*10000*275.8e-2;
k35 = scale(2)*1*.5*9e4; %1/mM/min = 1.5e8/M/sec -- Brzezinski and Adelroth has tau = 9us for 1mM O2, seems closest to Sucheta, Szundi et al model from Biochem 1999
k36 = scale(3)*500000*4.6e20;
k_36 = scale(3)*500000*4.6e5;
k37 = scale(4)*3.5e12;
k_37 = scale(4)*3.5e4;
d5 = 0.5;

a12 = k34*exp(-d5*4*Dpsi/RT_over_F)*c_red^3*(10^-(pH_n-3))^4;
a14 = k_37*exp((1-d5)*Dpsi/RT_over_F)*Hi;
a21 = k_34*exp((1-d5)*4*Dpsi/RT_over_F)*c_ox^3*Hi;
a23 = k35*simParams.O2;
a23 = a23*simParams.CNBlock;
a34 = k36*exp(-d5*3*Dpsi/RT_over_F)*c_red*(10^-(pH_n-3))^3;
a41 = k37*exp(-d5*Dpsi/RT_over_F)*(10^-(pH_n-3));
a43 = k_36*exp((1-d5)*3*Dpsi/RT_over_F)*c_ox*Hi^2;

%  numerator
E(1) = a21*a41*a34+a41*a34*a23;                             % Y
E(2) = a12*a41*a34;                                         % Yr
E(3) = a23*a12*a41+a43*a14*a21+a23*a43*a12+a23*a43*a14;     % YO
E(4) = a14*a34*a21+a34*a23*a12+a14*a34*a23;                 % YOH
% denominator
D = E(1) + E(2) + E(3) + E(4);
% fractions
Y = E(1)/D;
Yr = E(2)/D;
YO = E(3)/D;
YOH = E(4)/D;

v34 = 1e-3/60*C4_tot*(Y*a12 - Yr*a21)* simParams.tmp4;
v35 = 1e-3/60*C4_tot*Yr*a23* simParams.tmp4;
v36 = 1e-3/60*C4_tot*(a34*YO - a43*YOH)* simParams.tmp4;
v37 = 1e-3/60*C4_tot*(a41*YOH - a14*Y)* simParams.tmp4;

Ve = 3*v34 + v35; % rate of consumption of reduced cyt c
%this is the number of protons taken out of the matrix, not pumped across because some go to H2O
VHup = 5*VNO_c1+2*v3+4*v34+3*v36+v37;

VH = v34+2*v36+v37; % number of protons pumped across the matrix
VO2 = v35;          % O2 consumption of O2: two oxygen atoms, which requires 4 electrons

VhRes = 4*VNO_c1+2*v3+VH;



%% -------------ETC derivatives--------------------------------------------

dQ_n = v5 - v7_bLox - v7_bLred - v1;
dQdot_n = v7_bLox + v7_bLred - v8_bLox - v8_bLred;
dQH2_n = v8_bLox + v8_bLred + v1 -v2;
dQH2_p = v2 - v3;
dQdot_p = v3 -v10 -v4_bHox - v4_bHred;
dQ_p = v10 + v4_bHox + v4_bHred - v5;
db1 = v7_bLox +v8_bLox - v4_bHox;
db2 = v4_bHox + v7_bLred + v8_bLred - v6;
db3 = -v4_bHred + v6 - v7_bLox - v8_bLox;
dFeS_ox = v9 - v3;
dc1_ox = v33 - v9;
dc_ox = Ve - v33;
JH=-VhRes + Vhu + VNaH + VPiC + Vhleak;
JATP_hidrolysis = 0.0;

dydt = [ ...
    3.0E-4*(Vuni-VnaCa);                                        %Cam (1)
    VANT-VATPase-VSL;                                           %ADPm (2)
    -(-VhRes+Vhu+VANT+Vhleak+VnaCa+2*Vuni+VIMAC)/1.812E-3;      %Dpsim (3)
    -Jres/2+VIDH+VKGDH+VMDH-VTHD;                               %NADHm (4)
    beta_matr*(JH);                         %Hm     (5)
    -VATPase+VPiC-VSL;                      %Pim    (6)
    VACO-VIDH-VIDH_NADP;                    %ISO    (7)
    VIDH+VAAT-VKGDH+VIDH_NADP;              %aKG    (8)
    VKGDH-VSL;                              %SCoA   (9)
    VSL-vc2;                                %Succ   (10)
    vc2-VFH;                                %FUM    (11)
    VFH-VMDH;                               %MAL    (12)
    VMDH-VCS-VAAT;                          %Oaa    (13)
    VIDH_NADP+VTHD-VGRm-VTxRm;              %NADPH  (14)
    VROS_SS+VROS_c1+v10-VMnSOD-VtrROS;      %SO2m   (15)
    Vm/Vem*VtrROS-VCuZnSOD;                 %SO2i   (16)
    0.5*VMnSOD-VdifH2O2-VGPXm-VTxPXm;       %H2O2m  (17)
    0.5*VCuZnSOD+Vm/Vem*VdifH2O2-VGPX-VTxPX-Vcat;  %H2O2i  (18)
    VGRm-VGPXm-VGRXm+VGST-VPSSGm;           % GSHm   (19)
    VGR-VGPX-VGRX-Vm/Vem*VGST-VPSSGi;       % GSHi   (20)
    5.0D-1*(VGPXm-VGRm)+VGRXm;              % GSSGm  (21)
    VTxRm-VTxPXm;                           % TrxSH2m (22)
    VTxR-VTxPX;                             % TrxSH2 (23)
    VPSSGm-VGRXm;                           % PSSGm (24)
    VPSSGi-VGRX;                            % PSSGi (25)
    dQ_n;                                   %       (26)
    dQdot_n;                                %       (27)
    dQH2_n;                                 %       (28)
    dQH2_p;                                 %       (29)
    dQdot_p;                                %       (30)
    dQ_p;                                   %       (31)
    db1;                                    %       (32)
    db2;                                    %       (33)
    db3;                                    %       (34)
    dFeS_ox;                                %       (35)
    dc1_ox;                                 %       (36)
    dc_ox;                                  %       (37)
    0.0;                                    %       (38)
    ];


%% Fluxes 

% See Mito_reactions.pdf for labeled diagram 

J=[VCS VACO VIDH VKGDH VSL VFH VMDH  vc1 vc2 v33 ...
    VO2 VATPase VANT VnaCa VNaH Vuni VPiC VTHD Vhleak VMnSOD ...
    VGPXm VTxR VGRX VTxPXm VCuZnSOD VTxRm VTxPX VGRm Vcat VAAT...
    VIMAC VIDH_NADP VROS_c1 v10];

return;